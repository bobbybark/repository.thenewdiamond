# script.diamondinfo
diamondinfo Kodi Add-on
