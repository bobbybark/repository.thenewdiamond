from imdb.parser.logging import logger as parent_logger

logger = parent_logger.getChild('http')
